package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Producto;
import com.example.demo.service.ProductoService;

@Controller
@RequestMapping("/api/productos")
//("/productos")
public class ProductoController {

	 @Autowired
	    private ProductoService productoService;

	    @GetMapping
	    public String listProductos(Model model) {
	        model.addAttribute("productos", productoService.findAll());
	        return "productos/list";
	    }
	    
	    @GetMapping("/buscar")
	    public String buscarProductos(@RequestParam("nombre") String nombre, Model model) {
	        List<Producto> productos = productoService.buscarProductosPorNombre(nombre);
	        model.addAttribute("productos", productos);
	        return "productos/list";
	    }
	    

	    @GetMapping("/new")
	    public String createProductoForm(Model model) {
	        model.addAttribute("producto", new Producto());
	        return "productos/form";
	    }
	    
	    

	    @PostMapping
	    public String saveProducto(@ModelAttribute Producto producto) {
	        productoService.save(producto);
	        return "redirect:/api/productos";
	    }

	    @GetMapping("/edit/{id}")
	    public String editProductoForm(@PathVariable("id") Long id, Model model) {
	        Optional<Producto> producto = productoService.findById(id);
	        if (producto.isPresent()) {
	            model.addAttribute("producto", producto.get());
	            return "productos/form";
	        }
	        return "redirect:/productos";
	    }

	    @PostMapping("/delete/{id}")
	    public String deleteProducto(@PathVariable("id") Long id) {
	        productoService.deleteById(id);
	        return "redirect:/productos";
	    }
	}